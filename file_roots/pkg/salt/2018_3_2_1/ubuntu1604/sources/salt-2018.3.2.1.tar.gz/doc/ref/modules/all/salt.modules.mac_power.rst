salt.modules.mac_power module
=============================

.. automodule:: salt.modules.mac_power
    :members:
