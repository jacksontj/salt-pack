=========================
salt.modules.alternatives
=========================

.. automodule:: salt.modules.alternatives
    :members: