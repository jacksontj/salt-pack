=================
salt.modules.ipmi
=================

.. automodule:: salt.modules.ipmi
    :members:
