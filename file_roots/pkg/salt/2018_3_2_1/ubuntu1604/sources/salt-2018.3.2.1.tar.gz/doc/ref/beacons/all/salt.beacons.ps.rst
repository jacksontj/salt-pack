salt.beacons.ps module
======================

.. automodule:: salt.beacons.ps
    :members:
