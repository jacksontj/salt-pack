===============
salt.beacons.sh
===============

.. automodule:: salt.beacons.sh
    :members: