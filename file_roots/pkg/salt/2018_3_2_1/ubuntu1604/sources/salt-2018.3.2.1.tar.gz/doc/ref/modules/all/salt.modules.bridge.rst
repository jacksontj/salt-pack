===================
salt.modules.bridge
===================

.. automodule:: salt.modules.bridge
    :members: