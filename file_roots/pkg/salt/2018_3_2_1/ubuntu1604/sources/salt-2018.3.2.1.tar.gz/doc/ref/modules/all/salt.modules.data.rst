=================
salt.modules.data
=================

.. automodule:: salt.modules.data
    :members: