===============================
salt.cloud.clouds.dimensiondata
===============================

.. automodule:: salt.cloud.clouds.dimensiondata
    :members:
