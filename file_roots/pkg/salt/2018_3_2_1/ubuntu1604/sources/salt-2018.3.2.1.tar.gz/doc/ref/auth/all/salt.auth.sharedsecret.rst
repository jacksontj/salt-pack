======================
salt.auth.sharedsecret
======================

.. automodule:: salt.auth.sharedsecret
    :members: