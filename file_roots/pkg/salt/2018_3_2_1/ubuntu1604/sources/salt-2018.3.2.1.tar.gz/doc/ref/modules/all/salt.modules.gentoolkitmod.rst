==========================
salt.modules.gentoolkitmod
==========================

.. automodule:: salt.modules.gentoolkitmod
    :members: