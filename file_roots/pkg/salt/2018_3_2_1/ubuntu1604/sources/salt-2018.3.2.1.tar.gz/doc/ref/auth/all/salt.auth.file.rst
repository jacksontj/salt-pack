==============
salt.auth.file
==============

.. automodule:: salt.auth.file
    :members:
