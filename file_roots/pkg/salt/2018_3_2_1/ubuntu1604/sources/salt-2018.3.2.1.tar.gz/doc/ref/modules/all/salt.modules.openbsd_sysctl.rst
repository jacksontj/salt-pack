===========================
salt.modules.openbsd_sysctl
===========================

.. automodule:: salt.modules.openbsd_sysctl
    :members:
