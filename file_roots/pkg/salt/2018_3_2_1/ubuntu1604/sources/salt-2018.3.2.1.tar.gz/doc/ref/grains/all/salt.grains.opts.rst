================
salt.grains.opts
================

.. automodule:: salt.grains.opts
    :members:
