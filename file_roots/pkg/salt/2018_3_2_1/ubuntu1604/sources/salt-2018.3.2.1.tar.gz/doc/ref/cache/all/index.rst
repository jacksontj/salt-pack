.. _all-salt.cache:

=============
Cache Modules
=============

.. currentmodule:: salt.cache

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    consul
    etcd_cache
    localfs
    mysql_cache
    redis_cache
