==============================
salt.modules.napalm_ntp module
==============================

.. automodule:: salt.modules.napalm_ntp
    :members:

