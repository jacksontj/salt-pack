================
salt.auth.yubico
================

.. automodule:: salt.auth.yubico
    :members: