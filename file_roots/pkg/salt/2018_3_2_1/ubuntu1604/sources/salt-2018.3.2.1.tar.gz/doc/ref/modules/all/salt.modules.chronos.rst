salt.modules.chronos module
===========================

.. automodule:: salt.modules.chronos
    :members:
