=====================
salt.modules.kerberos
=====================

.. automodule:: salt.modules.kerberos
    :members: