===============
salt.exceptions
===============

.. automodule:: salt.exceptions
    :members: