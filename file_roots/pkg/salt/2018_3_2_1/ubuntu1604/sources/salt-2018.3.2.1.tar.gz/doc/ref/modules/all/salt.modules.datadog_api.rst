========================
salt.modules.datadog_api
========================

.. automodule:: salt.modules.datadog_api
    :members: