===================
salt.modules.locate
===================

.. automodule:: salt.modules.locate
    :members: